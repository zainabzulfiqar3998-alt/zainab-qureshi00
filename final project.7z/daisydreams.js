const products = [
    {
        id: 1,
        name: "Red Rose Bouquet",
        category: "roses",
        price: 49.99,
        oldPrice: 69.99,
        image: "https://i.pinimg.com/1200x/73/e4/24/73e424877509e20034564e7d5f006aae.jpg",
        badge: "Best Seller",
        rating: 4.8,
        reviews: 124
    },
    {
        id: 2,
        name: "Pink Tulip Arrangement",
        category: "tulips",
        price: 39.99,
        oldPrice: null,
        image: "https://i.pinimg.com/736x/d6/4e/13/d64e137a3f14c1e6a1bacd5ced1be476.jpg",
        badge: "New",
        rating: 4.6,
        reviews: 87
    },
    {
        id: 3,
        name: "White Lily Bouquet",
        category: "lilies",
        price: 54.99,
        oldPrice: 64.99,
        image: "https://i.pinimg.com/1200x/b6/1f/1d/b61f1d66e3deb5bfadf5480e51c39369.jpg",
        badge: "Limited",
        rating: 4.9,
        reviews: 156
    },
    {
        id: 4,
        name: "Mixed Flower Bouquet",
        category: "bouquets",
        price: 59.99,
        oldPrice: null,
        image: "https://i.pinimg.com/1200x/84/ac/65/84ac65e61664893ac26269724c7c6876.jpg",
        badge: "Premium",
        rating: 4.7,
        reviews: 203
    },
    {
        id: 5,
        name: "Yellow Rose Collection",
        category: "roses",
        price: 44.99,
        oldPrice: 54.99,
        image: "https://i.pinimg.com/1200x/7d/11/89/7d1189453ccbd2762f8a1413a74fed2d.jpg",
        badge: "Sale",
        rating: 4.5,
        reviews: 92
    },
    {
        id: 6,
        name: "Purple Tulip Bundle",
        category: "tulips",
        price: 42.99,
        oldPrice: null,
        image: "https://i.pinimg.com/736x/30/40/78/304078de6cfacec3d1b840ff8fb144e0.jpg",
        badge: "Popular",
        rating: 4.6,
        reviews: 78
    },
    {
        id: 7,
        name: "Stargazer Lily Arrangement",
        category: "lilies",
        price: 64.99,
        oldPrice: 74.99,
        image: "https://i.pinimg.com/736x/a1/18/14/a1181430e38f7b3db46aab1c118f03b8.jpg",
        badge: "Luxury",
        rating: 4.9,
        reviews: 167
    },
    {
        id: 8,
        name: "Spring Garden Bouquet",
        category: "bouquets",
        price: 49.99,
        oldPrice: null,
        image: "https://i.pinimg.com/736x/a2/dd/2c/a2dd2c7a02dc2a6dfe1345d04d5a5511.jpg",
        badge: "Seasonal",
        rating: 4.7,
        reviews: 134
    }
];

// Cart data
let cart = [];

// Initialize the page
document.addEventListener('DOMContentLoaded', function () {
    renderProducts('all');
    startCountdown();
    updateCartUI();
});

// Render products
function renderProducts(category) {
    const productGrid = document.getElementById('product-grid');
    productGrid.innerHTML = '';

    const filteredProducts = category === 'all'
        ? products
        : products.filter(product => product.category === category);

    filteredProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}">
                        ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
                        <div class="product-actions">
                            <button class="action-btn" onclick="addToWishlist(${product.id})">
                                <i class="far fa-heart"></i>
                            </button>
                            <button class="action-btn" onclick="quickView(${product.id})">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <div class="product-category">${product.category}</div>
                        <h3 class="product-name">${product.name}</h3>
                        <div class="product-price">
                            <span class="current-price">$${product.price}</span>
                            ${product.oldPrice ? `<span class="old-price">$${product.oldPrice}</span>` : ''}
                        </div>
                        <div class="product-rating">
                            <div class="stars">
                                ${generateStars(product.rating)}
                            </div>
                            <span class="rating-count">(${product.reviews})</span>
                        </div>
                        <button class="add-to-cart" onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>
                `;
        productGrid.appendChild(productCard);
    });
}

// Generate star rating
function generateStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }

    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }

    return stars;
}

// Filter products
function filterProducts(category) {
    // Update active tab
    const tabs = document.querySelectorAll('.filter-tab');
    tabs.forEach(tab => {
        tab.classList.remove('active');
        if (tab.textContent.toLowerCase().includes(category) ||
            (category === 'all' && tab.textContent === 'All Products')) {
            tab.classList.add('active');
        }
    });

    // Render filtered products
    renderProducts(category);
}

// Add to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }

    updateCartUI();
    showToast(`${product.name} added to cart!`);
}

// Update cart UI
function updateCartUI() {
    const cartCount = document.getElementById('cart-count');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;

    // Update cart items
    if (cart.length === 0) {
        cartItems.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Your cart is empty</p>
                    </div>
                `;
    } else {
        cartItems.innerHTML = '';
        cart.forEach(item => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                        <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                        <div class="cart-item-info">
                            <div class="cart-item-name">${item.name}</div>
                            <div class="cart-item-price">$${item.price}</div>
                            <div class="cart-item-quantity">
                                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                                <div class="quantity-value">${item.quantity}</div>
                                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                                <button class="remove-item" onclick="removeFromCart(${item.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `;
            cartItems.appendChild(cartItem);
        });
    }

    // Update cart total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = `$${total.toFixed(2)}`;
}

// Update quantity
function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            updateCartUI();
        }
    }
}

// Remove from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartUI();
    showToast('Item removed from cart');
}

// Toggle cart
function toggleCart() {
    const cartSidebar = document.getElementById('cart-sidebar');
    const overlay = document.getElementById('overlay');

    cartSidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Checkout
function checkout() {
    if (cart.length === 0) {
        showToast('Your cart is empty');
        return;
    }

    showToast('Redirecting to checkout...');
    // In a real application, this would redirect to a checkout page
    setTimeout(() => {
        cart = [];
        updateCartUI();
        toggleCart();
        showToast('Order placed successfully!');
    }, 2000);
}

// Add to wishlist
function addToWishlist(productId) {
    const product = products.find(p => p.id === productId);
    showToast(`${product.name} added to wishlist!`);
}

// Quick view
function quickView(productId) {
    const product = products.find(p => p.id === productId);
    showToast(`Quick view: ${product.name}`);
}

// Subscribe to newsletter
function subscribeNewsletter(event) {
    event.preventDefault();
    const email = event.target.querySelector('input[type="email"]').value;
    showToast(`Thank you for subscribing with ${email}!`);
    event.target.reset();
}

// Show toast notification
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Countdown timer
function startCountdown() {
    // Set the date we're counting down to (7 days from now)
    const countDownDate = new Date();
    countDownDate.setDate(countDownDate.getDate() + 7);

    // Update the countdown every 1 second
    const countdownInterval = setInterval(function () {
        // Get today's date and time
        const now = new Date().getTime();

        // Find the distance between now and the count down date
        const distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result
        document.getElementById("days").textContent = days.toString().padStart(2, '0');
        document.getElementById("hours").textContent = hours.toString().padStart(2, '0');
        document.getElementById("minutes").textContent = minutes.toString().padStart(2, '0');
        document.getElementById("seconds").textContent = seconds.toString().padStart(2, '0');

        // If the count down is finished, display a message
        if (distance < 0) {
            clearInterval(countdownInterval);
            document.getElementById("countdown").innerHTML = "EXPIRED";
        }
    }, 1000);
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Header scroll effect
window.addEventListener('scroll', function () {
    const header = document.querySelector('header');
    if (window.scrollY > 100) {
        header.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
    } else {
        header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    }
});